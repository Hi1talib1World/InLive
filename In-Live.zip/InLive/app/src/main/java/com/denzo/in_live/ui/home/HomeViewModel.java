package com.denzo.in_live.ui.home;

import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

}