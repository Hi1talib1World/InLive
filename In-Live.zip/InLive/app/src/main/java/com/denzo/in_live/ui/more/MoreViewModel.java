package com.denzo.in_live.ui.more;

import androidx.lifecycle.ViewModel;

public class MoreViewModel extends ViewModel {


}