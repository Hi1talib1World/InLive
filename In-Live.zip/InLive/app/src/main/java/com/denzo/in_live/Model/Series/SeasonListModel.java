package com.denzo.in_live.Model.Series;

public class SeasonListModel {
}
