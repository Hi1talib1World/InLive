package com.denzo.in_live.Utils;


public class Constant {
    //TODO:Secure these apis
    private static final String root = "https://api.vidflix.net/v2/api/";
    public static final String home = root+"home/";
    public static final String update = root+"update/";
    public static final String search = root+"premium/11/search.php?query=";
    public static final String live_TV = root+"premium/11/?name=allchannels&is_series=4";
    public static final String agent = "Mozilla/5.0 (X11; Linux x86_64; rv:74.0) Gecko/20100101 Firefox/74.0";
}