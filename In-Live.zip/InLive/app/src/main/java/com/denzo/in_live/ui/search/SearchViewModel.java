package com.denzo.in_live.ui.search;

import androidx.lifecycle.ViewModel;

public class SearchViewModel extends ViewModel {



    public SearchViewModel() {
    }

}
